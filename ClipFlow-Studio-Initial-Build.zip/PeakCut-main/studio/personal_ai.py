"""Per-account BYOK settings. Keys are encrypted at rest with a server-local Fernet key.
The encryption key is persisted under DATA_DIR; back up that file with the database."""
import json, os, threading
from cryptography.fernet import Fernet, InvalidToken
from . import config

_lock = threading.RLock()
_KEY_FILE = config.DATA_DIR / '.user-ai-fernet-key'

def _fernet():
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    with _lock:
        if not _KEY_FILE.exists():
            tmp = _KEY_FILE.with_suffix('.tmp')
            tmp.write_bytes(Fernet.generate_key())
            try: os.chmod(tmp, 0o600)
            except OSError: pass
            try: tmp.replace(_KEY_FILE)
            except FileExistsError: tmp.unlink(missing_ok=True)
        try: os.chmod(_KEY_FILE, 0o600)
        except OSError: pass
        return Fernet(_KEY_FILE.read_bytes())

def _path(uid):
    # User ids are generated internally, but constrain the path regardless.
    import re
    if not re.fullmatch(r'[A-Za-z0-9_-]{1,80}', str(uid or '')): raise ValueError('Invalid account.')
    d = config.DATA_DIR / 'user-ai'
    d.mkdir(parents=True, exist_ok=True)
    return d / (uid + '.enc')

def get(uid):
    p = _path(uid)
    if not p.exists(): return {}
    try: return json.loads(_fernet().decrypt(p.read_bytes()).decode('utf-8'))
    except (InvalidToken, ValueError, OSError): return {}

def save(uid, data):
    payload = json.dumps(data, separators=(',', ':')).encode('utf-8')
    p = _path(uid); tmp = p.with_suffix('.tmp')
    with _lock:
        tmp.write_bytes(_fernet().encrypt(payload))
        try: os.chmod(tmp, 0o600)
        except OSError: pass
        tmp.replace(p)

def delete(uid):
    _path(uid).unlink(missing_ok=True)

def public(uid):
    d = get(uid)
    key = str(d.get('key') or '')
    return {'provider': d.get('provider',''), 'models': d.get('models',[]), 'base_url': d.get('base_url',''),
            'has_key': bool(key), 'key_hint': key[-4:] if len(key) >= 12 else '', 'configured': bool(d.get('provider'))}

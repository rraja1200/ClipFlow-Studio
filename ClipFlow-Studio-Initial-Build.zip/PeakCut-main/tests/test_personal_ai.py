"""Basic regression checks for encrypted per-user AI credentials."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

class PersonalAIEncryptionTests(unittest.TestCase):
    def test_user_keys_are_isolated_and_encrypted(self):
        from studio import personal_ai
        with tempfile.TemporaryDirectory() as td:
            with patch.object(personal_ai.config, 'DATA_DIR', Path(td)):
                personal_ai.save('user_a', {'provider':'gemini','models':['gemini-2.5-flash'],'key':'secret-user-a'})
                personal_ai.save('user_b', {'provider':'openai','models':['gpt-4o-mini'],'key':'secret-user-b'})
                self.assertEqual(personal_ai.get('user_a')['key'], 'secret-user-a')
                self.assertEqual(personal_ai.get('user_b')['key'], 'secret-user-b')
                self.assertNotIn(b'secret-user-a', (Path(td)/'user-ai'/'user_a.enc').read_bytes())
                self.assertNotIn(b'secret-user-b', (Path(td)/'user-ai'/'user_b.enc').read_bytes())
                personal_ai.delete('user_a')
                self.assertEqual(personal_ai.get('user_a'), {})
                self.assertEqual(personal_ai.get('user_b')['key'], 'secret-user-b')

if __name__ == '__main__': unittest.main()

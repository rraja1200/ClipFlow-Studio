# ClipFlow product build notes

This is a product-oriented fork of PeakCut (MIT-licensed upstream). The upstream clipping/rendering engine, authentication, creator workspaces, upload handling, job queue, captioning, and usage event tracking are retained. Upstream attribution and the MIT license are retained.

## Included in this build

- A separate **My AI Provider** page at `/my-ai` for each signed-in user.
- Per-user provider/model/base URL settings and API credentials.
- Credentials are encrypted at rest using Fernet. The first run creates `DATA_DIR/.user-ai-fernet-key` with owner-only permissions. Back up this file together with the database; losing it makes saved API keys unrecoverable.
- The AI runtime resolves the current signed-in user's own provider before falling back to the server owner's legacy default configuration.
- Per-user key save, remove, status, and connection-test endpoints: `GET/PUT/DELETE /api/my-ai` and `POST /api/my-ai/test`.
- Existing `/api/usage` remains the source for token/call history and clip workflow activity.

## Important: billing is not enabled in this build

The ₹499 / 30-day subscription and payment webhook are **not yet wired**. Do not take customer payments or advertise a paid plan as active until a payment provider, webhook signature verification, entitlement checks on upload/render routes, expiry handling, and admin refund/cancel workflows have been implemented and tested. No payment credentials are included.

## Run locally

1. Python 3.10+ and FFmpeg are required.
2. `python -m venv .venv && source .venv/bin/activate` (Windows: `.venv\\Scripts\\activate`).
3. `pip install -r requirements.txt`.
4. Copy `.env.example` to `.env` and configure the account mode and persistent data directory.
5. `python -m studio.server` and open the local URL shown in the terminal.
6. Sign in, then open `/my-ai` to save a personal AI provider key.

For a public multi-user deployment, use HTTPS, enable accounts, use PostgreSQL and persistent storage, set a strong application secret/session configuration, and back up the database plus the `.user-ai-fernet-key` file. A free hosting tier may sleep, cap disk/CPU, or delete local storage; it is not a reliable production video-rendering server.

## Validation

- `python -m py_compile studio/personal_ai.py studio/ai.py studio/server.py`
- `python -m unittest tests.test_personal_ai`

The existing upstream test suite should also be run in a fully provisioned environment with FFmpeg and model dependencies installed.

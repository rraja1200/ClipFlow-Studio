# ClipFlow Studio — self-hosted AI clipping platform

ClipFlow Studio is the working product build in this repository. It keeps the MIT-licensed PeakCut clipping/rendering engine as its foundation and adds a separate per-user BYOK credential layer. The upstream license and attribution are retained; this is a derivative build, not a claim of authorship over the upstream project.

## Current build

- Existing upload, URL import, live-stream, clip generation, caption, preview, download and job-status workflows from PeakCut.
- Existing account registration/login and user-separated workspaces.
- Per-user AI provider credentials at `/my-ai` (also linked from the account menu).
- Encrypted API keys at rest, with per-user provider/model selection and connection testing.
- Existing AI usage/token activity reporting at `/app/usage`.

## Roadmap before accepting customers

1. ₹499 / 30-day subscription checkout, verified payment webhook, expiry/renewal/cancellation and upload/render entitlement enforcement.
2. Full product rebrand (final product name/logo/domain still needs owner approval).
3. End-to-end multi-account tests with concurrent clip jobs and user-isolated provider credentials.
4. Production deployment with persistent PostgreSQL, object storage, HTTPS and worker capacity.

**Do not accept payments yet.** Subscription billing is not part of this initial build. The product is not production-ready for public customers until the roadmap's payment and operational controls are implemented and tested.

## Quick start

See upstream `README.md` and `DEPLOY.md` for installation and deployment prerequisites. Install requirements, configure `.env`, ensure FFmpeg is installed, then run `python -m studio.server`. After signing in, open `/my-ai` to add a personal provider key.
